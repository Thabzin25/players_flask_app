<script>
function toggleSidebar() 
{
  document.querySelector('.sidebar').classList.toggle('collapsed');
}
</script>
